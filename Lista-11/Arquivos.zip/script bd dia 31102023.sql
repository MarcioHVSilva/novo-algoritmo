-- Aula 11

-- Relacionamento n:n

-- Conceito de tabela associativa


CREATE DATABASE consultaMedica;

USE consultaMedica;

CREATE TABLE paciente(
idPaciente INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(45));

INSERT INTO paciente (nome) VALUES
('Chuck'),
('Jason'),
('Freira');

CREATE TABLE medico(
idMedico INT PRIMARY KEY AUTO_INCREMENT,
nome VARCHAR(45),
salario DECIMAL(10,2)) AUTO_INCREMENT = 100;

INSERT INTO medico (nome,salario) VALUES
('Bonnie',100.99),
('Freddie',500.99),
('Foxy',1000.99);


SELECT * FROM paciente;

SELECT * FROM medico;

-- Criar a tabela associativa

-- unir as duas tabelas

CREATE TABLE consulta(
idConsulta int,
fkPaciente int,
fkMedico int,
PRIMARY KEY (idConsulta, fkPaciente, fkMedico),
dtConsulta DATETIME,
CONSTRAINT fkPacCons FOREIGN KEY (fkPaciente) 
REFERENCES paciente(idPaciente),
CONSTRAINT fkMedCons FOREIGN KEY (fkMedico) 
REFERENCES medico (idMedico));

INSERT INTO consulta VALUES
(1,1,100,'2023-10-31 8:00:00'),
(2,1,100,'2023-12-07 8:00:00'),
(1,2,101,'2023-10-31 8:00:00'),
(1,1,101,'2023-10-31 11:00:00');

SELECT * FROM consulta;

SELECT paciente.nome as Paciente,
medico.nome as Medico,
consulta.dtConsulta as Consulta
FROM paciente JOIN consulta
ON idPaciente = fkPaciente
JOIN medico
on idMedico = fkmedico;

SELECT paciente.nome as Paciente,
medico.nome as Medico,
consulta.dtConsulta as Consulta
FROM paciente JOIN consulta
ON idPaciente = fkPaciente
JOIN medico
on idMedico = fkmedico
WHERE dtConsulta LIKE '2023-10-31%';



create database venda;

use venda;

drop database venda;
create table cliente(
idcliente int auto_increment primary key,
nome varchar(45),
email varchar(45),
endereço varchar(45),
fkcliente int,
constraint fkcliente foreign key (fkcliente)
references cliente (idcliente)
)auto_increment=100;

create table venda(
idvenda int auto_increment ,
totalvenda int,
dt datetime,
fkcliente int,
primary key(idvenda,fkcliente))auto_increment=0;


create table produto(
idproduto int auto_increment primary key,
nome varchar(45),
descricao varchar(100),
precoproduto decimal(10,2)
);



create table carrinho(
idcarrinho int,
fkproduto int,
fkvenda int,
fkcliente int,
qtdproduto int,
valordesc int,
primary key(idcarrinho,fkproduto,fkvenda,fkcliente)
);

insert into cliente (nome, email, endereço, fkcliente) values
('murilo','murilo@hotmail.com','Rua barros jardim do sol',null),
('marcelo','marcelo@outlook.com','Rua cereais,jardim da lua',null),
('luka','luka@gmail.com','Rua daimonds, jardim green',null),
('mario','mario@gmail.com','Rua anjos, jardim miriam',null);

update cliente set fkcliente =101 where idcliente=100;
update cliente set fkcliente =101 where idcliente=102;
update cliente set fkcliente =102 where idcliente=103;

select * from cliente;

insert into venda(totalvenda, dt, fkcliente) values
(10,'2023-10-31 13:11:00',101),
(20,'2023-10-31 13:15:00',102),
(40,'2023-10-22 08:00:00',103),
(60,'2023-10-18 07:00:00',104);


insert into produto(nome, descricao, precoproduto) values
('camisa','camisa nike, tamanho M',10),
('blusa','blusa puma,tamanho G',20),
('blusa','blusa nike camuflada, tamanho GG',40),
('tenis','tenis no modelo kevin durant 15 ',60);

insert into carrinho(idcarrinho, fkproduto, fkvenda, fkcliente, qtdproduto, valordesc) values(
1,1,1,101,5,10),
(2,2,2,102,5,20),
(3,3,3,103,5,40),
(4,4,4,101,1,60);

desc carrinho;


select * from cliente;
select * from venda;

select * from produto;

select * from carrinho;

select cliente.*,venda.*
from cliente
join venda
on venda.idvenda;

select cliente.*,venda.*
from venda
join cliente
on venda.idvenda
where cliente.nome like "mario";

select cliente.*,venda.*,indicador.*,produto.nome from cliente 
join cliente as indicador
on indicador.idcliente=cliente.fkcliente
join venda 
on venda.fkcliente=cliente.idcliente
join produto 
on produto.idproduto;


select venda.idvenda,produto.nome,venda.dt,venda.totalvenda 
from venda
join produto
on produto.idproduto
where venda.idvenda =6;

select nome,precoproduto,
sum(qtdproduto)soma,
sum(qtdproduto)* precoproduto from produto
join carrinho on fkproduto=idproduto;

select * from carrinho;
select * from venda;

select * from produto;

select * from carrinho;





